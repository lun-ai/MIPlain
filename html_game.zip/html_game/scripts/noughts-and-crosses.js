/**
 * Sets clicked square and also updates the turn.
 */
function boardClicked() {
    if (!ended && !explShown) {
        convertBoardToBoxes(prevBoard);
        if (this.innerHTML !== EMPTY) {
            return;
        }
        this.innerHTML = turn;
        createNextButton('nextQuestion', 'next', 'Proceed', setQuestion);
    }
}

function endExp(){
    document.getElementById('phase').textContent = 'End of Session';
    ended = true;
    var element = document.createElement('a');

    element.style.display = 'none';
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(record));
    element.setAttribute('download', participantID + '@' + Number(withExpl) + '#score#' + Date.now() + '.txt');
    element.click();

    window.location.href = 'submission.html';
//    var collection = document.createElement('a');
//    div.appendChild(collection);
//    collection.setAttribute('');
//    collection.setAttribute();

}

function nextPhase() {

    console.log('Record: ');
    phase += 1;
    record += '\n';

    if (phase > PHASE_SETTING.length) {
        stopCount();
        endExp();
    } else {
        console.log('Phase: ' + PHASE_NAMES[phase - 1]);
        document.getElementById('phase').textContent = PHASE_NAMES[phase - 1];
        document.getElementById('feedback').textContent = 'Feedback Panel';

        if (phase === 1) {
            alert(PHASE_NAMES[phase - 1] + '. You are going to answers '
                        + PHASE_SETTING[phase - 1]
                        + ' questions. You have '
                        + PHASE_TIME_SETTING[phase - 1] + ' seconds for each question.');
        } else if (acc[phase - 1] === 0) {
            alert(PHASE_NAMES[phase - 1] + '. You are going to answers '
                        + PHASE_SETTING[phase - 1]
                        + ' questions. You have '
                        + PHASE_TIME_SETTING[phase - 1] + ' seconds for each question.');
        }
//        if (phase === 2 || phase === 4) {
//            document.getElementById('instruction1').textContent = 'During this stage, you are going to play '
//                        + PHASE_SETTING[phase - 1] + ' games against a COMPUTER.';
//            document.getElementById('instruction2').textContent = 'Your OPPONENT plays according to MINIMAX.';
//            startCount();
//            startNewGame();
//        } else
//        document.getElementById('instruction1').textContent = 'During this stage, you are going to answers '
//                        + PHASE_SETTING[phase - 1]
//                        + ' questions. You have '
//                        + PHASE_TIME_SETTING[phase - 1] + ' seconds for each question.';
        document.getElementById('instruction3').textContent = '';
        startNewQuestion();
    }
}
