var N_SIZE = 3,
    EMPTY = '&nbsp;',
    // 5000, 10000 resolution depth are not sufficient for finding all boards that satisfy win_3 rule at move 2
    RESOLUTION_DEPTH = 15000,
    PHASE_SETTING = [8, 3, 5, 3, 5, 2, 2],
    PHASE_NAMES = [ 'Background Test',
                    'Train 4th Move',
                    'Test 4th Move',
                    'Train 3rd Move',
                    'Test 3rd Move',
                    'Train 2nd Move',
                    'Test 2nd Move' ],
    PHASE_TIME_SETTING = [30, 60, 30, 60, 30, 60, 30],
    WAIT_TIME = 50,
    TIMER_SLICE = 1000,
    PL_FILE_NAME = 'strategy.pl';

var boxes = [],
    sec = 0,
    t,
    turn = 'O',
    score = {
        'Player': 0,
        'Computer': 0,
        'Draw': 0
    },
    maxGameNum = 10,
    moves,
    ended = false,
    explShown = false,
    minimaxTable = canonicalData,
    boardRepreToCanonical = canonicalMap,
    record = '',
    prevBoard = [0, 0, 0, 0, 0, 0, 0, 0, 0],
    // count from 0 until equals PHASE_SETTING
    acc = [ 0,
            PHASE_SETTING[1],
            PHASE_SETTING[2],
            PHASE_SETTING[3],
            PHASE_SETTING[4],
            PHASE_SETTING[5],
            PHASE_SETTING[6] ],
    ansSubmitted = true,
    phase = 0,
    gamePlayer = -1,
    sampledQuestions = [],
    wrongQuestionTypes = [],
    questionScore = -100,
    // to store each viable binding of the variable B and C in the violated rule
    wrongMoveBoard = [],
    suggestionB = [],
    suggestionD1 = [],
    suggestionD2 = [];

var texts = String(window.location).split('=');
var participantID = Number(texts[texts.length - 1]);
var withExpl = participantID % 2 === 1;
console.log('With explanation: ' + withExpl);

//var questionConfigs = [ partitions[2],
//                        partitions[4],
//                        partitions[6] ];

var questionConfigs = [ JSON.parse(JSON.stringify(partitions[1])),
                        JSON.parse(JSON.stringify(partitions[3])),
                        JSON.parse(JSON.stringify(partitions[5])) ];

var questionConfigsDup = [ JSON.parse(JSON.stringify(partitions[1])),
                           JSON.parse(JSON.stringify(partitions[3])),
                           JSON.parse(JSON.stringify(partitions[5])) ];

//var mixedQuestionPool = [ partitions[2]['win_1'].concat(partitions[2]['win_2']).concat(partitions[2]['win_3']),
//                          partitions[4]['win_1'].concat(partitions[4]['win_2']).concat(partitions[4]['win_3']),
//                          partitions[6]['win_1'].concat(partitions[6]['win_2']).concat(partitions[6]['win_3']) ];

//var mixedQuestionPool = [ questionConfigs[0]['win_1'].concat(questionConfigs[0]['win_2']).concat(questionConfigs[0]['win_3']),
//                          questionConfigs[1]['win_1'].concat(questionConfigs[1]['win_2']).concat(questionConfigs[1]['win_3']),
//                          questionConfigs[2]['win_1'].concat(questionConfigs[2]['win_2']).concat(questionConfigs[2]['win_3']) ];

//var questionConfigs = [[0, 0, 0, 0, 0, 1, 0, 0, 2],
//                       [0, 0, 0, 0, 0, 0, 1, 2, 1],
//                       [0, 0, 0, 0, 0, 0, 0, 2, 1],
//                       [0, 0, 0, 0, 0, 1, 0, 2, 1],
//                       [1, 0, 0, 0, 0, 2, 0, 0, 1],
//                       [0, 0, 0, 0, 0, 1, 1, 0, 2],
//                       [0, 0, 0, 0, 0, 1, 1, 2, 0],
//                       [0, 0, 0, 1, 0, 2, 0, 0, 1],
//                       [0, 0, 0, 0, 1, 0, 0, 2, 1],
//                       [0, 0, 0, 0, 1, 0, 2, 0, 1]];
//    trainGameConfigs = [[0, 0, 0, 0, 1, 0, 0, 0, 2],
//                        [1, 0, 0, 0, 0, 0, 0, 2, 0],
//                        [2, 0, 0, 0, 0, 0, 0, 1, 0],
//                        [0, 0, 0, 0, 0, 0, 0, 1, 2],
//                        [1, 0, 0, 0, 0, 0, 0, 0, 2]],
//    testGameConfigs = [[0, 0, 0, 1, 0, 0, 0, 2, 0],
//                       [0, 0, 0, 0, 0, 1, 0, 2, 0],
//                       [0, 0, 0, 0, 0, 2, 0, 0, 1],
//                       [0, 0, 0, 0, 1, 0, 0, 1, 2],
//                       [0, 0, 0, 0, 1, 0, 0, 2, 1],
//                       [0, 0, 0, 0, 1, 1, 0, 0, 2]];