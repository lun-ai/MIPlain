% win strategy
win_1(A,B):- move(A,B),won(B).
win_2(A,B):- move(A,B), not(win_1(B,C)), not(move(B,C), not(win_1(C,D))).
win_3(A,B):- move(A,B), not(win_1(B,C)), not(win_2(B,C)), not(move(B,C), not(win_1(C,D)), not(win_2(C,D))).

% draw strategy
draw_1(A,B):- move(A,B),not(win_1(B,C)).
draw_2(A,B):- move(A,B),not(win_1(B,C)),not(win_2(B,C)).
draw_3(A,B):- move(A,B),not(win_1(B,C)),not(win_2(B,C)),not(win_3(B,C)).
draw_4(A,B):- move(A,B),not(win_1(B,C)),not(win_2(B,C)),not(win_3(B,C)).
